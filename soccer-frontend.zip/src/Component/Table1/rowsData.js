
const createData = (
  nr,
  Voornaam,
  Tussenv,
  Achternaam,
  Positie,
  Been,
  Geslacht,
  Geboortedautum,
  Leedtijd,
  Email,
  Telefoonnummer,
  Beheer
) => {

  return {
    nr,
    Voornaam,
    Tussenv,
    Achternaam,
    Positie,
    Been,
    Geslacht,
    Geboortedautum,
    Leedtijd,
    Email,
    Telefoonnummer,
    Beheer,
  };
};

export default [
  createData(
    "1",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",

   
  ),
 
  createData(
    "1",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",

    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    
  ),
  createData(
    "1",
    "abc",
    "abc",
    "abc",
  
    "abc",

    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc"
  ),
  createData(
    "1",
    "abc",
    "abc",
    "abc",
    "abc",

    "abc",
  
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc"
  ),
  createData(
    "1",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",


    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc"
  ),
  createData(
    "1",
    "abc",
    "abc",
    "abc",
 
    "abc",

    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc"
  ),
  createData(
    "1",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
   

    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc"
  ),
  createData(
    "1",
    "abc",
    "abc",
    "abc",
 
    "abc",

    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc"
  ),
  createData(
    "1",
    "abc",
    "abc",
    "abc",
    "abc",
   

    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc"
  ),

  createData(
    "1",
    "abc",
    "abc",
    "abc",
    "abc",


    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc"
  ),
  createData(
    "1",
    "abc",
    "abc",
    "abc",
    "abc",

    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc"
  ),
  createData(
    "1",
    "abc",
    "abc",
    "abc",
    "abc",
   

    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc"
  ),
];
