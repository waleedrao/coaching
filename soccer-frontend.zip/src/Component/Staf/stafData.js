const createData = (
    functie,
Voornaam,
  Tussenv,
  Achternaam,
  Geslacht,
  Geboortedautum,
  Email,
  Telefoonnummer,
  Beheer
) => {
  return {
    functie,
    Voornaam,
    Tussenv,
    Achternaam,
    Geboortedautum,
    Geslacht,
    Email,
    Telefoonnummer,
    Beheer,
  };
};

export default [
  createData(
   "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc",
    "abc"


  ),
];
