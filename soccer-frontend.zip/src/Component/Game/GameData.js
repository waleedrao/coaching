const createData = (nr, Voornaam, Tussenv, Achternaam, Positie, Been) => {
  return {
    nr,
    Voornaam,
    Tussenv,
    Achternaam,
    Positie,
    Been,
  };
};

export default [
  createData("1", "abc", "abc", "abc", "abc", "abc"),

  createData("1", "abc", "abc", "abc", "abc", "abc"),
  createData("1", "abc", "abc", "abc", "abc", "abc"),
  createData("1", "abc", "abc", "abc", "abc", "abc"),
  createData("1", "abc", "abc", "abc", "abc", "abc"),
  createData("1", "abc", "abc", "abc", "abc", "abc"),
  createData("1", "abc", "abc", "abc", "abc", "abc"),
  createData("1", "abc", "abc", "abc", "abc", "abc"),
  createData("1", "abc", "abc", "abc", "abc", "abc"),

  createData("1", "abc", "abc", "abc", "abc", "abc"),
  createData("1", "abc", "abc", "abc", "abc", "abc"),
  createData("1", "abc", "abc", "abc", "abc", "abc"),
];
